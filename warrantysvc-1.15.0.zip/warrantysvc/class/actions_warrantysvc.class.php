<?php
/* Copyright (C) 2026 DPG Supply */

/**
 * \file    class/actions_warrantysvc.class.php
 * \ingroup warrantysvc
 * \brief   Hook actions for the Warranty & Service module
 */

/**
 * Class ActionsWarrantySvc
 *
 * Implements Dolibarr hooks so that svcwarranty and svcrequest element types
 * are recognised system-wide — appearing in the "Link to" dropdown on any
 * Dolibarr object card (shipments, orders, projects, etc.).
 */
class ActionsWarrantySvc
{
	/** @var DoliDB Database handler */
	public $db;

	/** @var string Error message */
	public $error = '';

	/** @var array Result set returned to hook manager */
	public $results = array();

	/** @var string HTML output injected by hook into the page */
	public $resprints = '';

	/**
	 * Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * Provide element properties for svcwarranty and svcrequest so Dolibarr
	 * can resolve them in linked-object lookups and the "Link to" dropdown.
	 *
	 * Called by HookManager on the 'elementproperties' context.
	 * 'warrantysvc' is kept as a backward-compat alias for svcrequest to handle
	 * any existing llx_element_element rows written before the $element fix.
	 *
	 * @param  array      $parameters  Hook parameters, including $parameters['elementType']
	 * @param  object     &$object     Current page object (not used)
	 * @param  string     &$action     Current action (not used)
	 * @param  HookManager $hookmanager Hook manager instance
	 * @return int                     0 = merge results via array_replace
	 */
	public function getElementProperties($parameters, &$object, &$action, $hookmanager)
	{
		$elementType = isset($parameters['elementType']) ? $parameters['elementType'] : '';

		if ($elementType === 'svcwarranty') {
			$this->results = array(
				'module'        => 'warrantysvc',
				'element'       => 'svcwarranty',
				'table_element' => 'svc_warranty',
				'subelement'    => 'svcwarranty',
				'classpath'     => 'warrantysvc/class',
				'classfile'     => 'svcwarranty',
				'classname'     => 'SvcWarranty',
			);
		} elseif ($elementType === 'svcrequest' || $elementType === 'warrantysvc') {
			// 'warrantysvc' is a backward-compat alias for existing llx_element_element rows
			$this->results = array(
				'module'        => 'warrantysvc',
				'element'       => 'svcrequest',
				'table_element' => 'svc_request',
				'subelement'    => 'svcrequest',
				'classpath'     => 'warrantysvc/class',
				'classfile'     => 'svcrequest',
				'classname'     => 'SvcRequest',
			);
		}

		return 0;
	}

	/**
	 * Inject a "Linked Warranties & Service Requests" block onto supported native
	 * Dolibarr card pages (orders, shipments, invoices, interventions, projects).
	 *
	 * Uses the same showLinkToObjectBlock / showLinkedObjectBlock pattern as
	 * warranty_card.php so the native "Link to..." hyperlink appears at the top
	 * right of the block, letting users manually create links to svcwarranty and
	 * svcrequest records stored in llx_element_element.
	 *
	 * Called by HookManager on the 'globalcard' context.
	 *
	 * @param  array      $parameters  Hook parameters (includes 'context')
	 * @param  object     &$object     Current page object
	 * @param  string     &$action     Current action
	 * @param  HookManager $hookmanager Hook manager instance
	 * @return int                     0 = continue other hooks
	 */
	public function formObjectOptions($parameters, &$object, &$action, $hookmanager)
	{
		global $langs, $db, $user, $form;

		if (!isModEnabled('warrantysvc')) return 0;

		// Only fire on supported native element types
		$supported = array('commande', 'expedition', 'facture', 'fichinter', 'project');
		if (!isset($object->element) || !in_array($object->element, $supported)) return 0;

		// Skip non-view modes
		if (in_array($action, array('create', 'edit', 'delete', 'add', 'update'))) return 0;

		// Require a persisted object
		if (empty($object->id) || $object->id <= 0) return 0;

		// Require at least one warrantysvc read permission
		if (!$user->hasRight('warrantysvc', 'svcwarranty', 'read')
		 && !$user->hasRight('warrantysvc', 'svcrequest', 'read')) return 0;

		if (!is_object($form)) {
			require_once DOL_DOCUMENT_ROOT.'/core/class/html.form.class.php';
			$form = new Form($db);
		}
		$langs->load('warrantysvc@warrantysvc');

		$tmparray = $form->showLinkToObjectBlock($object, array(), array(), 1);
		$linktoelem      = isset($tmparray['linktoelem'])      ? $tmparray['linktoelem']      : '';
		$htmltoenteralink = isset($tmparray['htmltoenteralink']) ? $tmparray['htmltoenteralink'] : '';

		ob_start();
		print $htmltoenteralink;
		$form->showLinkedObjectBlock($object, $linktoelem);
		$this->resprints = ob_get_clean();

		return 0;
	}
}
